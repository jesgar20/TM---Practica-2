package com.example.cambiodemonedas

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etMonto: EditText
    private lateinit var spnDivisas: Spinner
    private lateinit var tvResultado: TextView

    // Lista de monedas solicitadas
    private val monedas = arrayOf(
        "Dólar (USA)", "Euro (Europa)", "Libra (Inglaterra)",
        "Rupia (India)", "Real (Brasil)", "Peso (México)",
        "Yuan (China)", "Yen (Japón)"
    )

    private val tiposCambio = floatArrayOf(
        0.27f,   // Dólar
        0.25f,   // Euro
        0.21f,   // Libra
        22.30f,  // Rupia
        1.35f,   // Real
        4.50f,   // Peso MX
        1.95f,   // Yuan
        40.50f   // Yen
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        etMonto = findViewById(R.id.etMonto)
        spnDivisas = findViewById(R.id.spnDivisas)
        tvResultado = findViewById(R.id.tvResultado)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, monedas)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnDivisas.setAdapter(adapter)
    }

    fun miClicManejador(view: View) {
        val cantidadTexto = etMonto.text.toString().trim()

        if (cantidadTexto.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un monto", Toast.LENGTH_SHORT).show()
            return
        }

        val soles = cantidadTexto.toFloatOrNull()

        if (soles != null && soles > 0) {
            val posicion = spnDivisas.selectedItemPosition
            val monedaSeleccionada = monedas[posicion]
            val factorConversion = tiposCambio[posicion]

            val resultado = soles * factorConversion

            tvResultado.text = "Resultado: ${"%.2f".format(resultado)} $monedaSeleccionada"
        } else {
            Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show()
        }
    }
}